import javax.swing.*;

public class MainForm {
    private JPanel panel1;
    private JButton button1;
}
