package InternalAssesment;


public class User {
    public final int newspaperCreativityIndex = 0;
    public final int debateCreativityIndex = 1;
    public final int tripCreativityIndex = 2;

    public final int gymActivityIndex = 3;
    public final int danceActivityIndex = 4;
    public final int martialArtsActivityIndex = 5;

    public final int treesServiceIndex = 6;
    public final int redCrossServiceIndex = 7;
    public final int developmentServiceIndex = 8;

    public String username;
    public String password;
    public String[] progress;
}
